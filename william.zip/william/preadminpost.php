<?php

   header('Location:admin.php?idclient=' . $_POST['client'] );
?>