<?php

header('location:Connexion.php');
?>