<?php
include('includes/database.php');
 
//verification de l'existance de du nom dans le post
if(!isset($_POST['nameAbo'])){
	header('Location: abonnementinsertbdd.php?error=nameAbo_missing');
	exit;
}
if(!isset($_POST['acces'])){
	header('Location: abonnementinsertbdd.php?error=textacces_missing');
	exit;
}

if(!isset($_POST['time'])){
	header('Location: abonnementinsertbdd.php?error=texttime_missing');
	exit;
}
// REQUETE PREPAREE (PROTECTION CONTRE L'INJECTION SQL)
$q = "INSERT INTO user (nameAbo,acces,time) VALUES (:nameAbo,:acces,:time)";

$req = $bdd->prepare($q);



$req->execute(array(
	'nameAbo' => $_POST['nameAbo'],
	'acces' => $_POST['acces'],
	'time' => $_POST['time']
	)
);
		header('Location: abonnementinsertbdd.php?verification=ok');
		exit;
?>