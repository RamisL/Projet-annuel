<?php session_start(); ?>
<!Doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title> HomeService </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<?php
    include("header.php");
    include("session.php");
    include("chatbot.php");
?>
   <div class="servicebdd">
        <p>Ajoutez un abonnement</p>
        <form action="abonnementinsertbdd.php" method="post">
            <input type="text" name="name" placeholder="Nom du service">
            <br><br>
            <textarea  name="acces" rows="5" cols="33" placeholder="Définiser les acces"></textarea>
            <br><br>
            <textarea  name="time" rows="5" cols="33" placeholder="Définiser le temps de service par mois"></textarea>
            <br><br>
            <input  type="submit" name="buttunproduit" value="Ajouter"/>
        </form>
    </div> 
</body>
