<?php session_start(); ?>
<!Doctype html>
<html>

<head>
    <meta charset="utf-8">
    <title> HomeService </title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<?php
    include("header.php");
    include("session.php");
    include("chatbot.php");
?>
    <div class="texteajoutservices" >
        <ul><span>Vous ne trouvez pas le service recherché ?</span></ul>
        <ul><span>Demander de l'ajouter a notre site <a href="aservice.php">ici</a> !</span></ul>
    </div>
</body>