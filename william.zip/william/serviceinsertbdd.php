<?php

include('includes/database.php');


if(!isset($_POST['name']) || empty($_POST['name'])){
	header('Location: produitbdd.php?error=name_missing');
	exit;
}

if(!isset($_POST['description']) || empty($_POST['description'])){
	header('Location: produitbdd.php?error=name_missing');
	exit;
}

if(!isset($_POST['link']) || empty($_POST['link'])){
	header('Location: produitbdd.php?error=link_missing');
	exit;
}

if(!isset($_POST['stock']) || empty($_POST['stock'])){
	header('Location: produitbdd.php?error=stock_missing');
	exit;
}
if(!isset($_POST['price']) || empty($_POST['price'])){
	header('Location: produitbdd.php?error=price_missing');
	exit;
}

// Vérification que le nom n'est pas déjà utilisé
$req = $bdd->prepare('SELECT name FROM image WHERE name= ?');
$req->execute(array($_POST['name']));
// Parcourir la réponse de la bdd
$answers = [];
while($user = $req->fetch()){
	$answers[] = $user;
} 
if(count($answers) != 0){ // le tableau n'est pas vide : l'email est déjà pris
	header('Location: produitbdd.php?error=name_taken');
	exit;
}

$img = "INSERT INTO image (name,description,link,stock,price) VALUES (:name,:description,:link,:stock,:price)";

$req = $bdd->prepare($img);

$req->execute(array(
	'name' => $_POST['name'],
	'description' => $_POST['description'],
	'link' => $_POST['link'],
	'stock' => $_POST['stock'],
	'price' => $_POST['price']
	)
);
		header('Location: produitbdd.php?verification=ok');
		exit;
?>